package basic;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class FormServlet extends HttpServlet{
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException{
		req.setCharacterEncoding("euc-kr");
		res.setContentType("text/html;charset=euc-kr");
		
		PrintWriter pw = res.getWriter();
		
		String name = req.getParameter("name");
		String addr = req.getParameter("addr");
		String[] language = req.getParameterValues("language");
		String save = req.getParameter("save");
		
		String language_Val = "";
		if(language == null || language.length == 0) {
			language_Val = "��� ������ language�� �����ϴ�";
		}else {
			for(int i =0; i < language.length; i++) {
				language_Val = language_Val + language[i]+ " ";
			}
		}
	
		if(name.length() == 0 || name == null) {
			name = "<�̸��� �Է��ϼ���>";
		}
		if(addr.length() == 0 || addr == null) {
			addr = "<�ּ��� �Է��ϼ���>";
		}
		if(save == null) {
			save = "<�Է����� ���������� �����ϼ���>";
		}
		
		pw.print("<h1>name	:" + name  +"</h1>");
		pw.print("<h1>addr	:" + addr  +"</h1>");
		pw.print("<h1>language	:" + language_Val  +"</h1>");
		pw.print("<h1>save	:" + save  +"</h1>");
		
		
		
	}
}
