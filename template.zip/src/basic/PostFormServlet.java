package basic;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class PostFormServlet extends HttpServlet{
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException{
	
			req.setCharacterEncoding("euc-kr");
			res.setContentType("text/html;charset=euc-kr");
			
			PrintWriter pw = res.getWriter();
			
			//��û����
			String id 		= req.getParameter("userId");
			String name 	= req.getParameter("userName");
			String password = req.getParameter("passwd");
			String gender = req.getParameter("gender");
			String job 	= req.getParameter("job");
			String[] item	= req.getParameterValues("item"); 
			String item_val = "";
			
			System.out.println("id : " + id );
			System.out.println("name : " + name );
			System.out.println("password : " + password );
			System.out.println("gender : " + gender );
			System.out.println("job : " + job );
			
			pw.print("<h1>���̵�	:" + id +"</h1>");
			pw.print("<h1>�̸�		:" + name +"</h1>");
			pw.print("<h1>�н�����	:" + password +"</h1>");
			pw.print("<h1>����	:" + gender +"</h1>");
			pw.print("<h1>����	:" + job +"</h1>");
					
			for(int i = 0; i < item.length; i++) {
				System.out.println("item : " + item[i] );
				item_val = item_val + item[i] + " ";
			}
			pw.print("<h1>��ȣ�о�	:" + item_val +"</h1>");
	}
	
}
