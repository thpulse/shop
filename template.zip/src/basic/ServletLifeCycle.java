package basic;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ServletLifeCycle extends HttpServlet{
		public ServletLifeCycle() {
			System.out.println("ServletLifeCycle��ü�� ����");
		}
		
		public void init(){
			System.out.println("init()");
		}
	
	
		public void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException{
			System.out.println("service!");
			//��û����� get�̸� doGet�� ȣ���ϰ� ��û����� post�� doPost�� ȣ���ϵ��� ����
			
			if(req.getMethod().equals("GET")) {
				doGet(req, res);
				System.out.println("Get Method");
			}else {
				doPost(req, res);
			}
		}
		
	public void doGet(HttpServletRequest req, HttpServletResponse res){
		System.out.println("do Get!");
	}
	
	public void doPost(HttpServletRequest req, HttpServletResponse res){
		System.out.println("do Post!");
	}
	
	public void destroy() {
		System.out.println("destroy!!");
	}
}
