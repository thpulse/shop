package basic;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Calc extends HttpServlet {
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException{
		req.setCharacterEncoding("euc-kr");
		res.setContentType("text/html;charset=euc-kr");
		
		PrintWriter pw = res.getWriter();
		
		String num1 = req.getParameter("num1");
		String num2 = req.getParameter("num2");
		String method = req.getParameter("method");
		
		int result = calc(Integer.parseInt(num1), Integer.parseInt(num2), method);
		pw.print("<h1>������	:" + result  +"</h1>");
		
	}
	public int calc(int num1,int num2,String opr){
		int result = 0;//�������� ������ ����
		switch(opr){
			case "+":
				result = num1+ num2;
				break;
			case "*":
				result = num1* num2;
				break;
			case "-":
				result = num1- num2;
				break;
			case "/":
				result = num1/ num2;
				break;
			default:
				System.out.println("�߸��Է�");
				System.exit(0);//���α׷��� ���� �����϶�� �ǹ�
		}
		return result;
	}
}
