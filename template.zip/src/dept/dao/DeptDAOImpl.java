package dept.dao;

import static fw.DBUtil.close;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


import dept.dto.DeptDTO;
import static fw.Query.*;

public class DeptDAOImpl implements DeptDAO {
	@Override
	public int insert(DeptDTO deptInfo, Connection con) throws SQLException {
		int result = 0;
		System.out.println("dao" + deptInfo);//�����
		
		PreparedStatement ptmt = con.prepareStatement(DEPT_INSERT);
		
		ptmt.setString(1, deptInfo.getMgr());
		ptmt.setString(2, deptInfo.getTel());
		ptmt.setString(3, deptInfo.getLoc());
		ptmt.setString(4, deptInfo.getDeptName());
		ptmt.setString(5, deptInfo.getDeptNo());
		
		result = ptmt.executeUpdate();
		
		if(result > 0) {
			System.out.println("���Լ���");
		}else {
			System.out.println("���Խ���");
		}
		close(ptmt);
		return result;
	}
	@Override
	public ArrayList<DeptDTO> selectAll(Connection con) throws SQLException {
		ArrayList<DeptDTO> result = new ArrayList<DeptDTO>();
		ResultSet rs = null;
		System.out.println("DeptDAOImpl selectAll()");
		PreparedStatement ptmt = con.prepareStatement(selectAll);
		rs = ptmt.executeQuery();
		while(rs.next()) {
			DeptDTO dto = new DeptDTO();
			dto.setMgr(rs.getString(1));
			dto.setTel(rs.getString(2));
			dto.setLoc(rs.getString(3));
			dto.setDeptName(rs.getString(4));
			dto.setDeptNo(rs.getString(5));
			result.add(dto);
		}
		return result;
		
	}
	@Override
	public int delete(String deptNo, Connection con) throws SQLException {
		int result ;
		System.out.println("DeptDAOImpl delete : " + deptNo);
		
		PreparedStatement ptmt = con.prepareStatement(delete);
		ptmt.setString(1, deptNo);
		result = ptmt.executeUpdate();
		return result;
	}
	@Override
	public DeptDTO read(String deptName, Connection con)
			throws SQLException {
		
		return null;
	}
	@Override
	public int update(DeptDTO dto, Connection con) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}
	
	
	@Override
	public ArrayList<DeptDTO> findByName(String deptName, Connection con)
			throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public ArrayList<DeptDTO> findDeptName(Connection con) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public ArrayList<DeptDTO> search(String deptName, Connection con)
			throws SQLException {
		ArrayList<DeptDTO> result = new ArrayList<DeptDTO>();
		
		ResultSet rs = null;
		PreparedStatement ptmt = con.prepareStatement(search);
		ptmt.setString(1,  deptName);
		rs = ptmt.executeQuery();
		
		while(rs.next()) {
			DeptDTO dto = new DeptDTO();
			dto.setMgr(rs.getString(1));
			dto.setTel(rs.getString(2));
			dto.setLoc(rs.getString(3));
			dto.setDeptName(rs.getString(4));
			dto.setDeptNo(rs.getString(5));
			result.add(dto);
		}
		return result;
	}
}
