package dept.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Vector;

import dept.dto.DeptDTO;

public interface DeptDAO {
	
	public ArrayList<DeptDTO> selectAll(Connection con) throws SQLException; 
	public ArrayList<DeptDTO> search(String deptName, Connection con)throws SQLException;
	
	public int delete(String deptNo, Connection con) throws SQLException;
	public int insert(DeptDTO dto,Connection con) throws SQLException;
	public int update(DeptDTO dto,Connection con) throws SQLException;
	public DeptDTO read(String deptNo, Connection con) throws SQLException;
	
	public ArrayList<DeptDTO> findByName(String deptName, Connection con) throws SQLException;
	public ArrayList<DeptDTO> findDeptName(Connection con) throws SQLException;
	
	
}
