package dept.service;

import static fw.DBUtil.close;
import static fw.DBUtil.getConnection;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Vector;

import dept.dao.DeptDAO;
import dept.dao.DeptDAOImpl;
import dept.dto.DeptDTO;
public class DeptServiceImpl implements DeptService {

	@Override
	public int insert(DeptDTO deptInfo) {
		int result = 0;
		System.out.println("service : " +deptInfo);
		DeptDAO dao = new DeptDAOImpl();
		Connection con = null;
		try {
			/*
			 * DBUtil�� �޼ҵ带 ȣ���Ͽ� Connection�� �����ؼ� dao��
			 * insert�� ����
			 */
			con = getConnection();
			result = dao.insert(deptInfo, con);
		} catch(SQLException e) {
			e.printStackTrace();
		}finally {
			close(con);
		}
		return result;
	}
	
	@Override
	public ArrayList<DeptDTO> selectAll() {
		ArrayList<DeptDTO> result = new ArrayList<DeptDTO>();
		System.out.println("DeptServiceImpl selectAll()");
		DeptDAO dao = new DeptDAOImpl();
		Connection con = null;
		try {
			con = getConnection();
			result = dao.selectAll(con);
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			close(con);
		}
		return result;
	}

	@Override
	public int delete(String deptNo) {
		int result=0;
		System.out.println("DeptServiceImpl delete : " + deptNo);
		DeptDAO dao = new DeptDAOImpl();
		Connection con = null;
		try {
			con = getConnection();
			result = dao.delete(deptNo, con);
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			close(con);
		}
		return result;
	}

	@Override
	public DeptDTO read(String deptName) {
		DeptDTO result = new DeptDTO();
		System.out.println("DeptServiceImpl search : " + deptName);
		DeptDAO dao = new DeptDAOImpl();
		Connection con = null;
		try {
			con = getConnection();
			result = dao.read(deptName, con);
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			close(con);
		}
		return result;
	}

	@Override
	public int update(DeptDTO dto) {
		// TODO Auto-generated method stub
		return 0;
	}


	@Override
	public ArrayList<DeptDTO> findByName(String deptName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<DeptDTO> findDeptName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<DeptDTO> search(String deptName) {
		ArrayList<DeptDTO> result = new ArrayList<DeptDTO>();
		DeptDAO dao = new DeptDAOImpl();
		Connection con = getConnection();
		try{
			result = dao.search(deptName, con);
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			close(con);
		}
		return result;
	}
	
}
