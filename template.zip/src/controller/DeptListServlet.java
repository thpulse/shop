package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dept.dto.DeptDTO;
import dept.service.DeptService;
import dept.service.DeptServiceImpl;


@WebServlet(name = "list", urlPatterns = { "/list.do" })
public class DeptListServlet extends HttpServlet {
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException{
		
	}
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
		req.setCharacterEncoding("euc-kr");
		res.setContentType("text/html;charset=euc-kr");
		
		PrintWriter pw = res.getWriter();
		/*
		pw.print("<table border='1' width='500'>");
		pw.print("<th>�μ���</th><th>�μ��ڵ�</th><th>��ġ</th>");
		pw.print("<th>������</th><th>��ȭ��ȣ</th><th>����</th>");
		*/
		DeptService service = new DeptServiceImpl();
		ArrayList<DeptDTO> result = new ArrayList<DeptDTO>();
		result = service.selectAll();
		/*
		for(int i=0; i < result.size(); i++) {
			DeptDTO dto = result.get(i);
			pw.print("<tr bgcolor = 'skyblue'>");
			pw.print("<td>" + dto.getDeptName() + "</td>");
			pw.print("<td>" + dto.getDeptNo() + "</td>");
			pw.print("<td>" + dto.getLoc() + "</td>");
			pw.print("<td>" + dto.getMgr() + "</td>");
			pw.print("<td>" + dto.getTel() + "</td>");
			pw.print("<td><a href = '/serverweb/delete.do?deptno=" + dto.getDeptNo()+"'>����</a></td>");
			pw.print("</tr>");
		}
		pw.print("</table>");*/
		
		req.setAttribute("result", result); 
		req.setAttribute("mainurl", "../jspbasic/list.jsp");
		RequestDispatcher rd =
				req.getRequestDispatcher("/layout/mainLayout.jsp");
		rd.forward(req,res);
		
	}
}
