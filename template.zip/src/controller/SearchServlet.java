package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dept.dto.DeptDTO;
import dept.service.DeptService;
import dept.service.DeptServiceImpl;
@WebServlet(name = "search", urlPatterns = { "/search.do" })
public class SearchServlet extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		
		req.setCharacterEncoding("euc-kr");
		res.setContentType("text/html;charset=euc-kr");
				
		PrintWriter pw = res.getWriter();
		
		String search_Val = req.getParameter("search_Val");
		ArrayList<DeptDTO> result = new ArrayList<DeptDTO>();
		DeptService service = new DeptServiceImpl();
		result = service.search(search_Val);
		
		req.setAttribute("result", result); 
		req.setAttribute("mainurl", "../jspbasic/list.jsp");
		RequestDispatcher rd =
				req.getRequestDispatcher("/layout/mainLayout.jsp");
		rd.forward(req,res);
	}
}
