package app3;
public abstract class MyBeanStyle {
	public abstract void testHello(String string); 
}
