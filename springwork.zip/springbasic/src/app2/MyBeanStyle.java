package app2;
public abstract class MyBeanStyle {
	public abstract void testHello(String string); 
}
