package app2;

public class MyBeanStyleA extends MyBeanStyle {
	public void testHello(String name){
		System.out.println("A �ȳ��ϼ���! : " + name );
	}

	
}
