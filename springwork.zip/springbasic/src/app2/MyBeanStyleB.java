package app2;

public class MyBeanStyleB extends MyBeanStyle {
	public void testHello(String name){
		System.out.println("B Hello!!!! : " + name );
	}
}
