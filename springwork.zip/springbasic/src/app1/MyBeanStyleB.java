package app1;

public class MyBeanStyleB {
	public void testHello(String name){
		System.out.println("B Hello!!!! : " + name );
	}
}
