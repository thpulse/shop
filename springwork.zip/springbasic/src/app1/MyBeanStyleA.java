package app1;

public class MyBeanStyleA {
	public void testHello(String name){
		System.out.println("A �ȳ��ϼ���! : " + name );
	}
}
