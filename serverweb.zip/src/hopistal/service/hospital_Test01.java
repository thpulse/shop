package hopistal.service;

import hospi_find_DTO.hospi_find_DTO;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * Servlet implementation class hospital_Test01
 */
@WebServlet(name = "hospital_find_map", urlPatterns = { "/hospital_find_map.do" })
public class hospital_Test01 extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("euc-kr");
		response.setContentType("text/html;charset=euc-kr");
		ArrayList<hospi_find_DTO> dtolist = new ArrayList<hospi_find_DTO>();
		
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		try {
			String addr_Val = "http://openapi.e-gen.or.kr/openapi/service/rest/HsptlAsembySearchService/getHsptlMdcncListInfoInqire?ServiceKey=iKjCF%2FtYGVQ0XGlYT%2Fmr35pn3khauFnt6RZple05Yw9er75Kbh0DqQQ2%2FIb1zbhZnMpYuh%2BgHhOQ1WITAcIMgQ%3D%3D&Q0=%EC%84%9C%EC%9A%B8%ED%8A%B9%EB%B3%84%EC%8B%9C&Q1=%EC%84%9C%EC%B4%88%EA%B5%AC&QZ=B&QD=D001&QT=1&ORD=NAME&numOfRows=2&pageNo=1";
			URL url = new URL(addr_Val);
			InputStream data = url.openStream();
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document dom = builder.parse(data);
			Element root = dom.getDocumentElement();
			
			//Ư��������Ʈ������ ���ǵ� node�� ����
			NodeList itemlist = root.getElementsByTagName("item");
			dtolist = new ArrayList<hospi_find_DTO>();
			System.out.println("������ ����� ���� : " + itemlist.getLength());
			
			for(int i = 0; i < itemlist.getLength(); i++) {
				Node itemNode = itemlist.item(i);
				Element childItem = (Element) itemNode;
				String lat = getText(childItem, "wgs84Lat");
				String lon = getText(childItem, "wgs84Lon");
				hospi_find_DTO dto = new hospi_find_DTO(lat, lon);
				dtolist.add(dto);
			}
			printDom(dtolist);
			
		} catch (ParserConfigurationException | SAXException | IOException e) {
			e.printStackTrace();
		}
		String menu = "dept_menu.jsp";
		String mainurl = "../test/hosMapTest01.jsp";
		
		request.setAttribute("result", dtolist);
		request.setAttribute("menu", menu);
		request.setAttribute("mainurl", mainurl);
		RequestDispatcher rd =
				request.getRequestDispatcher("/layout/mainLayout.jsp");
		rd.forward(request,response);
	}
	public static String getText(Element itemnode, String tag) {
		String nodeVal = "";
		Node itemchildNode = itemnode.getElementsByTagName(tag).item(0);
		nodeVal = itemchildNode.getChildNodes().item(0).getNodeValue();
		return nodeVal;
	}
	public static void printDom(ArrayList<hospi_find_DTO> itemlist) {
		for(int i = 0; i < itemlist.size(); i++) {
			hospi_find_DTO result = itemlist.get(i);
			System.out.print(result.getWgs84Lat() + "\t");
			System.out.println(result.getWgs84Lon() + "\t");
		}
	}

}
