package hopistal.service;

import fw.getService;
import hospi_find_DTO.hospi_find_DTO;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.json.XML;

public class hospital_findService {
	
	//Lat, Lon, Name��ȯ
	public ArrayList<hospi_find_DTO> hosFindBysigungu(String sido, String gungu){
		ArrayList<hospi_find_DTO> result_list = new ArrayList<hospi_find_DTO>();
		//url -> string
		getService service = new getService();
		JSONParser parser = new JSONParser();
		StringBuilder urlBuilder = new StringBuilder("http://openapi.e-gen.or.kr/openapi/service/rest/HsptlAsembySearchService/getHsptlMdcncListInfoInqire"); /*URL*/
        try {
			urlBuilder.append("?" + URLEncoder.encode("ServiceKey","UTF-8") + "=iKjCF%2FtYGVQ0XGlYT%2Fmr35pn3khauFnt6RZple05Yw9er75Kbh0DqQQ2%2FIb1zbhZnMpYuh%2BgHhOQ1WITAcIMgQ%3D%3D");
			 urlBuilder.append("&" + URLEncoder.encode("Q0","UTF-8") + "=" + URLEncoder.encode(sido, "UTF-8")); /*�ּ�(�õ�)*/
		        urlBuilder.append("&" + URLEncoder.encode("Q1","UTF-8") + "=" + URLEncoder.encode(gungu, "UTF-8")); /*�ּ�(�ñ���)*/
		        urlBuilder.append("&" + URLEncoder.encode("QZ","UTF-8") + "=" + URLEncoder.encode("B", "UTF-8")); /*�������*/
		        urlBuilder.append("&" + URLEncoder.encode("QD","UTF-8") + "=" + URLEncoder.encode("D001", "UTF-8")); /*�������*/
		        urlBuilder.append("&" + URLEncoder.encode("QT","UTF-8") + "=" + URLEncoder.encode("1", "UTF-8")); /*�������*/
		        urlBuilder.append("&" + URLEncoder.encode("ORD","UTF-8") + "=" + URLEncoder.encode("NAME", "UTF-8")); /*���ı���*/
		        urlBuilder.append("&" + URLEncoder.encode("numOfRows","UTF-8") + "=" + URLEncoder.encode("999", "UTF-8")); /*�˻��Ǽ�*/
		        urlBuilder.append("&" + URLEncoder.encode("pageNo","UTF-8") + "=" + URLEncoder.encode("1", "UTF-8")); /*������ ��ȣ*/
		        URL url = new URL(urlBuilder.toString());
		        System.out.println(url);
		       //xml -> json
		        org.json.JSONObject xmlJsonObj = XML.toJSONObject(service.getUrl(url.toString()));
		       String out = xmlJsonObj.toString();		     		       
		      
		       //Lat, Lon, Name��ȯ
		       JSONObject rootObj = (JSONObject)parser.parse(out);
		       JSONObject rootObj_response = (JSONObject) rootObj.get("response");
		       JSONObject rootObj_body = (JSONObject) rootObj_response.get("body");
		       
		       //��� �˻��� ������� null��ȯ
		       String result_chk = rootObj_body.get("totalCount").toString();
		       if(result_chk.equals("0")){
		    	   result_list = null;
		    	   System.out.println("�Ұ�");
		       }else {
		    	   JSONObject rootObj_items = (JSONObject) rootObj_body.get("items");
			       JSONArray itemArray = (JSONArray)rootObj_items.get("item");
			       for(int i =0; i < itemArray.size(); i++){
			    	   JSONObject info = (JSONObject)itemArray.get(i);
			    	   String lat = info.get("wgs84Lon").toString();
			    	   String lon = info.get("wgs84Lat").toString();
			    	   String dutyName = (String)info.get("dutyName");
			    	   String hpid = (String)info.get("hpid");
			    	   hospi_find_DTO dto = new hospi_find_DTO(lat, lon, dutyName, hpid);
			    	   result_list.add(dto);		    	   
			       }		       
		    	   
		       }
		       
		} catch (IOException | ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}      
		return result_list;
	}
	public static void main(String[] args){
		hospital_findService service = new hospital_findService();
		System.out.println(service.hosFindBysigungu("����Ư����", "������"));
	}
}
