package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dept.dto.DeptDTO;
import dept.service.DeptService;
import dept.service.DeptServiceImpl;
@WebServlet(name = "forward", urlPatterns = { "/forward.do" })
public class SearchServlet extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		
		req.setCharacterEncoding("euc-kr");
		res.setContentType("text/html;charset=euc-kr");
				
		PrintWriter pw = res.getWriter();
		
		String search_Val = req.getParameter("search_Val");
		ArrayList<DeptDTO> result = new ArrayList<DeptDTO>();
		DeptService service = new DeptServiceImpl();
		result = service.search(search_Val);
		
		/*pw.print("<table border='1' width='500'>");
		pw.print("<th>�μ���</th><th>�μ��ڵ�</th><th>��ġ</th>");
		pw.print("<th>������</th><th>��ȭ��ȣ</th>");
		
		for(int i=0; i < result.size(); i++) {
			DeptDTO dto = result.get(i);
			pw.print("<tr bgcolor = 'skyblue'>");
			pw.print("<td>" + dto.getDeptName() + "</td>");
			pw.print("<td>" + dto.getDeptNo() + "</td>");
			pw.print("<td>" + dto.getLoc() + "</td>");
			pw.print("<td>" + dto.getMgr() + "</td>");
			pw.print("<td>" + dto.getTel() + "</td>");
			//pw.print("<td><a href = '/serverweb/delete.do?deptno=" + dto.getDeptNo()+"'>����</a></td>");
			pw.print("</tr>");
		}
		pw.print("</table>");*/
		
		req.setAttribute("result", result); 
		RequestDispatcher rd =
				req.getRequestDispatcher("test2/select_main.jsp");
		rd.forward(req,res);
	}
	
	
	

}
