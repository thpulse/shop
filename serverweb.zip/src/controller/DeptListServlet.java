package controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dept.dto.DeptDTO;
import dept.service.DeptService;
import dept.service.DeptServiceImpl;
import emp.dto.EmpDTO;

@WebServlet(name = "dept_search", urlPatterns = { "/dept_search.do" })
public class DeptListServlet extends HttpServlet {
	
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
		req.setCharacterEncoding("euc-kr");
		res.setContentType("text/html;charset=euc-kr");
		
		String action = req.getParameter("action");		
		
		DeptService service = new DeptServiceImpl();
		ArrayList<DeptDTO> result = new ArrayList<DeptDTO>();
		result = service.selectAll();					
		req.setAttribute("result", result);
		
		//���ø��� ����� view���� (mainLayout.jsp�� ����)
		HttpSession ses = req.getSession(false); //������ ������ �ִ°� �޾ƿ;��Ѵ�.
		EmpDTO loginUser = null;
		if(ses !=null) {
			loginUser = (EmpDTO)ses.getAttribute("loginUser");
		}
		String menu = "";
		String mainurl="";
		//�α��������ʰ� �����ϴ� ��� �α��� �������� ������ �� �ֵ��� ����		
		if(loginUser == null){
			menu = "servlet_menu.jsp";
			mainurl = "../emp/login.jsp";
		}else {
			menu = "dept_menu.jsp";
			if(action.equals("AJAX")) {
				System.out.println("AJAX");
				mainurl = "../dept/dept_ajax_list.jsp";
			}else if(action.equals("EMPLIST")){
				mainurl = "../dept/dept_list_and_emp.jsp";
			}else {
				mainurl = "../dept/dept_list.jsp";
			}			
		}
		req.setAttribute("menu", menu);
		req.setAttribute("mainurl", mainurl);
		RequestDispatcher rd =
				req.getRequestDispatcher("/layout/mainLayout.jsp");
		rd.forward(req,res);		
	}
}
