package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dept.dto.DeptDTO;
import dept.service.DeptService;
import dept.service.DeptServiceImpl;

@WebServlet(description = "dept_read", urlPatterns = { "/dept_read.do" })
public class ReadServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("euc-kr");
		response.setContentType("text/html;charset=euc-kr");
		
		String deptNo_Val = request.getParameter("deptNo");
				
		DeptService service = new DeptServiceImpl();
		DeptDTO result = service.read(deptNo_Val);
		System.out.println("ReadServlet result : " + result);
		
		request.setAttribute("result", result); 
		request.setAttribute("menu", "../layout/dept_menu.jsp");
		request.setAttribute("mainurl", "../dept/dept_read.jsp");
		
		RequestDispatcher rd =
				request.getRequestDispatcher("/layout/mainLayout.jsp");
	
		rd.forward(request,response);
	}

}
