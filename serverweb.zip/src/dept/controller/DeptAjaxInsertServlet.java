package dept.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Vector;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.catalina.connector.Request;

import dept.dto.DeptDTO;
import dept.service.DeptService;
import dept.service.DeptServiceImpl;

@WebServlet(name = "ajaxinsert", urlPatterns = { "/ajaxinsert.do" })
public class DeptAjaxInsertServlet extends HttpServlet{
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
		req.setCharacterEncoding("utf-8");
		String deptno 	= req.getParameter("deptno");
		String deptname = req.getParameter("deptname");
		String loc 		= req.getParameter("loc");
		String tel 		= req.getParameter("tel");
		String mgr 		= req.getParameter("mgr");
		
		DeptDTO dto = new DeptDTO();
		dto.setDeptNo(deptno);
		dto.setDeptName(deptname);
		dto.setLoc(loc);
		dto.setMgr(mgr);
		dto.setTel(tel);
		System.out.println("DeptAjaxInsertServlet dto : " + dto);
		
		DeptService service = new DeptServiceImpl();
		int result = service.insert(dto);
		
		
		//���Ŀ� �ʿ��� �ڵ带 �ۼ��ϰ� ajax��û�� �������� ������ �Ѿ��.
		
		
	}
}
