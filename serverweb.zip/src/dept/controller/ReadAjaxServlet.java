package dept.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONObject;

import dept.dto.DeptDTO;
import dept.service.DeptService;
import dept.service.DeptServiceImpl;

/**
 * Servlet implementation class ReadAjaxServlet
 */
@WebServlet(name = "read_ajax", urlPatterns = { "/read_ajax.do" })
public class ReadAjaxServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		
		String deptNo = (String)request.getParameter("deptNo");
		DeptService service = new DeptServiceImpl();
		DeptDTO dto = new DeptDTO();
		dto = service.read(deptNo);
	
		//JSON Maker
		JSONObject jsonResult = new JSONObject();
		jsonResult.put("deptNo", dto.getDeptNo());
		jsonResult.put("deptName", dto.getDeptName());
		jsonResult.put("loc", dto.getLoc());
		jsonResult.put("tel", dto.getTel());
		jsonResult.put("mgr", dto.getMgr());
		
		response.setContentType("application/json;charset=utf-8");
		response.setHeader("cache-control", "no-cache,no-store");
		PrintWriter pw = response.getWriter();
		pw.print(jsonResult.toJSONString());
				
	}

}
