package json;

import java.io.FileWriter;
import java.io.IOException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

/*
 * 	mydata.json������ �ۼ� - FileWriter
 * 	{}	:	Json Object
 * 	[]	:	Json Array
 */
public class JSONMaker {

	public static void main(String[] args) throws IOException {
		JSONObject myjson = new JSONObject();
		myjson.put("name", "������");
		myjson.put("age", "25");
		
		JSONArray subjectlist = new JSONArray();
		subjectlist.add("java");
		subjectlist.add("servlet");
		subjectlist.add("spring");
		subjectlist.add("hadoop");
		
		myjson.put("subjectlist", subjectlist);
		
		//json���� ����
		FileWriter fw = new FileWriter("src/json/mydata.json");
		fw.write(myjson.toJSONString());
		System.out.println(myjson.toJSONString());
		fw.flush();
		fw.close();
	}

}
