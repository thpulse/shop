package json;

import java.io.FileWriter;
import java.io.IOException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

/*
 * 	mydata.json������ �ۼ� - FileWriter
 * 	{}	:	Json Object
 * 	[]	:	Json Array
 */
public class JSONMaker2 {

	public static void main(String[] args) throws IOException {
		JSONObject myjson = new JSONObject();
		myjson.put("name", "������");
		myjson.put("age", "25");
		
		JSONArray likelist = new JSONArray();
		likelist.add("java");
		likelist.add("servlet");
		likelist.add("spring");
	
		myjson.put("like", likelist);
		
		JSONObject addr = new JSONObject();
		addr.put("zipcode", "���Ϸ�");
		addr.put("addr1", "�����");
		addr.put("addr2", "�����");
		
		myjson.put("addr", addr);
		
		JSONObject history = new JSONObject();
		history.put("subject", "java");
		history.put("month", "9");
		
		JSONObject history2 = new JSONObject();
		history2.put("subject", "web");
		history2.put("month", "10");
		
		JSONObject history3 = new JSONObject();
		history3.put("subject", "spring & bigdata");
		history3.put("month", "11");
		
		JSONArray historylist = new JSONArray();
		historylist.add(history);
		historylist.add(history2);
		historylist.add(history3);
		
		myjson.put("history", historylist);
		
		//json���� ����
		FileWriter fw = new FileWriter("src/json/mydata.json");
		fw.write(myjson.toJSONString());
		System.out.println(myjson.toJSONString());
		fw.flush();
		fw.close();
	}

}
