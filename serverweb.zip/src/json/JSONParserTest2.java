package json;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/*
 * mydata.json������ �Ľ�
 * name 	: 
 * age  	:
 * subject 	: 
 */
public class JSONParserTest2 {
	public static void main(String[] args) {
		
		JSONParser parser = new JSONParser();
		try {
			JSONObject rootObj = (JSONObject)parser.parse(new FileReader("src/json/mydata.json"));
					
			String name = (String)rootObj.get("name");
			String age = (String)rootObj.get("age");
			System.out.print("name : " + name);
			System.out.println("age : " + age);
					
			JSONArray likelist = (JSONArray)rootObj.get("like");
			for(int i =0; i < likelist.size(); i++) {
				String like = (String)likelist.get(i);
				System.out.println("like " +  i +  " : " + like);
			}
			
			JSONArray historylist = (JSONArray)rootObj.get("history");
			for(int j = 0; j < historylist.size(); j++) {
				JSONObject history = (JSONObject)historylist.get(j);
				String month = (String)history.get("subject");
				String subject = (String)history.get("month");
				System.out.print("history" + "[" + j + "]." + "subject : " + month +"\t\t");
				System.out.println("history" + "[" + j + "]." + "month : " + subject + "\t\t");
			}
		}catch(FileNotFoundException e){
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		
	}	

}
