package json;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/*
 * mydata.json������ �Ľ�
 * name 	: 
 * age  	:
 * subject 	: 
 */
public class JSONParserTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//	1. JSON�ļ� ����
		JSONParser parser = new JSONParser();
		//	2. JSON�Ľ��ϱ� - JSONObject�� �ޱ�
		try {
			JSONObject rootObj = 
					(JSONObject)parser.parse(new FileReader("src/json/mydata.json"));
			
			//3. JSONObject�� ���� �����͸� �б�(get)
			String name = (String)rootObj.get("name");
			String age = (String)rootObj.get("age");
			System.out.println("name : " + name);
			System.out.println("age : " + age);
			
			//4. JSONArray�ޱ�
			JSONArray jsonArray = (JSONArray)rootObj.get("like");
			for(int i =0; i < jsonArray.size(); i++) {
				String data = (String)jsonArray.get(i);
				System.out.println(data + " ");
			}
		}catch(FileNotFoundException e){
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		
	}	

}
