package sidogungu;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import sidogungu.controller.gunguService;
import sidogungu.controller.sidoService;

/**
 * Servlet implementation class sidoServlet
 */
@WebServlet(name = "sido", urlPatterns = { "/hosfind_sido.do" })
public class sidogunguServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("euc-kr");
		//�õ� �ڵ�ȹ��
		String sido_InputVal = request.getParameter("sido_Val");
		System.out.println("sidoServlet sido_inputVal : " + sido_InputVal);
		sidoService service =  new sidoService();
		String sido_OutputVal = service.getsidoCode(sido_InputVal);
		System.out.println("sidoServlet Val :" + sido_OutputVal);
		
		//�õ��ڵ带 ���� ���� ��ȯ
		gunguService service_gungu = new gunguService();
		ArrayList<String> gungu_OutVal = service_gungu.getgunguCode(sido_OutputVal);
		System.out.println("getgunguCode " + gungu_OutVal);
		
		JSONObject gungu_json = new JSONObject();
		JSONArray gungu_json_list = new JSONArray();
		String[] out = null ;
		for(int i =0; i < gungu_OutVal.size();i++){
			JSONObject gungu_json_obj = new JSONObject();
			String result = gungu_OutVal.get(i);
			out = result.split(",");
			gungu_json_obj.put("admCode", out[0].toString());
			gungu_json_obj.put("lowestAdmCodeNm", out[1].toString());
			gungu_json_list.add(gungu_json_obj);			
		}
		gungu_json.put("gungu_json", gungu_json_list);
		response.setContentType("application/json;charset=utf-8");
		response.setHeader("cache-control", "no-cache,no-store");
		PrintWriter pw = response.getWriter();
		pw.print(gungu_json.toString());		
	}

	
}
