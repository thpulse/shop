package sidogungu;

import hopistal.service.hospital_findService;
import hospi_find_DTO.hospi_find_DTO;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import sidogungu.controller.gunguService;
import sidogungu.controller.sidoService;

@WebServlet(name = "findHospital", urlPatterns = { "/findHospital.do" })
public class findHospitalServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("EUC-KR");
		
		//sidogungu.jsp -> �õ�,���� �ڵ�����
		System.out.println("findhospital.do");
		String sido_InputVal = request.getParameter("sidogun_Val");
		String gungu_InputVal = request.getParameter("sido_Val2");
		System.out.println(sido_InputVal);
		System.out.println(gungu_InputVal);
		
		//�õ��ڵ� -> �õ��̸�
		sidoService service =  new sidoService();
		String sido_Name = service.getsidoName(sido_InputVal);
		System.out.println("findHospitalServlet sido_Name :" + sido_Name);
		
		//�����ڵ� -> �����̸�
		gunguService service2 = new gunguService();
		String gungu_Name = service2.getgunguName(gungu_InputVal);
		System.out.println("findHospitalServlet gungu_Name :" + gungu_Name);
		
		//�õ�, �����̸� -> �Ƿ��api -> ������������
		hospital_findService service3 = new hospital_findService();
		ArrayList<hospi_find_DTO> hoslist = new ArrayList<hospi_find_DTO>();
		hoslist = service3.hosFindBysigungu(sido_Name, gungu_Name);
		System.out.println("findHospitalServlet hoslist : " + hoslist);
						
		//-------------hoslist null���̸� ������ ���ٴ� �� ---�˻���������� ������ -----------------
		JSONObject hospi_json = null;
		JSONArray hospi_json_list = null;
		if(hoslist == null) {
			String pass = "Adsfadsf";
			JSONObject hospi_json_obj = new JSONObject();
			hospi_json_obj.put("totalCount", pass);
			hospi_json.put("hospi_json", hospi_json_obj);
		}else {
			//������������(�̸�,����,�浵) -> sidogungu.jsp
			hospi_json = new JSONObject();
			hospi_json_list = new JSONArray();
			int hostlistSize = hoslist.size();
			for(int i =0; i < hostlistSize; i++){
				JSONObject hospi_json_obj = new JSONObject();
				hospi_find_DTO dto = hoslist.get(i);
				hospi_json_obj.put("DutyName", dto.getDutyName());
				hospi_json_obj.put("Lat", dto.getWgs84Lat());
				hospi_json_obj.put("Lon", dto.getWgs84Lon());
				hospi_json_obj.put("hpid", dto.getHpid());
				hospi_json_list.add(hospi_json_obj);	
				hospi_json.put("hospi_json", hospi_json_list);
			}
		}		
		response.setContentType("application/json;charset=utf-8");
		response.setHeader("cache-control", "no-cache,no-store");
		PrintWriter pw = response.getWriter();
		pw.print(hospi_json.toString());
		System.out.println(hospi_json.toString());
		
		
	}
}
