package openapi.dto;

public class PharmacyDTO {
	private String addr;
	private String emdongNm;
	private String telno;
	
	public PharmacyDTO(){}
	
	public PharmacyDTO(String addr, String emdongNm, String telno) {
		super();
		this.addr = addr;
		this.emdongNm = emdongNm;
		this.telno = telno;
	}
	
	
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public String getEmdongNm() {
		return emdongNm;
	}
	public void setEmdongNm(String emdongNm) {
		this.emdongNm = emdongNm;
	}
	public String getTelno() {
		return telno;
	}
	public void setTelno(String telno) {
		this.telno = telno;
	}
	
}

