package openapi;

import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class HTMLParserTest02 {

	public static void main(String[] args) {
		
		try {
			Document doc = Jsoup.connect("http://weather.naver.com/period/pastWetrMain.nhn?ym=201610&naverRgnCd=09680").get();
			if(doc != null) {
				Elements elements = doc.select("table.tbl_calendar > tbody > tr > td:not(.no)");
				int size = elements.size();
				for(int i =0; i < size; i++) {
					Element element = elements.get(i);
					System.out.println(element.select("strong:not(span.temp_mn > strong, span.temp_mx > strong").text() + " ��, ");
					
					System.out.print("������� : " + element.select("span.temp_mn > strong").text());
					System.out.println(" , �ְ���� : " + element.select("span.temp_mx > strong").text());
				}
			}
		} catch (IOException e) {
			
			e.printStackTrace();
		}

	}

}
