package openapi.logic;

import java.io.BufferedInputStream;
import java.net.URL;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import openapi.DeptDTO;
import openapi.dto.PharmacyDTO;

public class OpenAPILogicImpl implements OpenAPILogic {

	@Override
	public ArrayList<PharmacyDTO> getPaharmacyList() {
		ArrayList<PharmacyDTO> paharmacyList = new ArrayList<PharmacyDTO>();
		
		DocumentBuilderFactory factory 
						= DocumentBuilderFactory.newInstance();
		try {
			DocumentBuilder builder = 
							factory.newDocumentBuilder();
			String pharmurl = 
					"http://openapi.hira.or.kr/openapi/service/pharmacyInfoService/getParmacyBasisList";
			String key="rtXyzvtNloEBJC0rtjlfRgr026JEgjNKDhOh%2F5VjvhYppyhbkbcuYDCxa7MDv1Ooc%2BuPCEezvaYRDHcEPls%2B6w%3D%3D";
			
			String urldata =pharmurl+"?ServiceKey="+key; 
			URL url = new URL(urldata);	
			BufferedInputStream bis = 
					new BufferedInputStream(url.openStream());
			Document dom = builder.parse(bis);
			Element root = dom.getDocumentElement();
			NodeList nodelist = root.getElementsByTagName("item");
			for (int i = 0; i < nodelist.getLength(); i++) {
				Node itemnode = nodelist.item(i);
				Element childitem = (Element)itemnode;
				String addr = getText(childitem, "addr");
				String emdongNm = getText(childitem, "emdongNm");
				String telno = getText(childitem, "telno");
				PharmacyDTO paharmacy = new PharmacyDTO(addr, emdongNm, telno);
				paharmacyList.add(paharmacy);
			}
			//����ϴ� ����� �޼ҵ� ȣ��
		//printDOM(paharmacyList);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return paharmacyList;
	}
	public static String getText(Element childitem, String tagName){
		String nodeVal = "";
		Node itemchildNode = 
				childitem.getElementsByTagName(tagName).item(0);
		if(itemchildNode!=null){//�̺κ��� ��� ����ϰ� �������� ���� �ٸ��� ������ �־�� �մϴ�. 
			nodeVal = 
					itemchildNode.getChildNodes().item(0).getNodeValue();
		}
		return nodeVal;
	}
	/*public static void main(String[] args){
		new OpenAPILogicImpl().getPaharmacyList();
	}
	public static void printDOM(ArrayList<PharmacyDTO> paharmacyList){
		for (int i = 0; i < paharmacyList.size(); i++) {
			PharmacyDTO dept = paharmacyList.get(i);
			System.out.print(dept.getAddr()+"\t");
			System.out.print(dept.getEmdongNm()+"\t");
			System.out.println(dept.getTelno()+"\t");
		
		}
	}*/
}
