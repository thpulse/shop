package openapi.logic;

import java.util.ArrayList;

import openapi.dto.PharmacyDTO;

public interface OpenAPILogic {
	ArrayList<PharmacyDTO> getPaharmacyList();
}
