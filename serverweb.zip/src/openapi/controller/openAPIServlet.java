package openapi.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import openapi.dto.PharmacyDTO;
import openapi.service.OpenAPIService;
import openapi.service.OpenAPIServiceImpl;

@WebServlet(name = "openapi_list", urlPatterns = { "/openapi_list.do" })
public class openAPIServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		OpenAPIService service = new OpenAPIServiceImpl();
		ArrayList<PharmacyDTO> pharmacyList = service.getPaharmacyList();
		request.setAttribute("pharmacyList",pharmacyList);
		
		request.setAttribute("menu","ad_menu.jsp");
		request.setAttribute("mainurl","../openapi/pharmacyList.jsp");
		
		RequestDispatcher rd = 
			request.getRequestDispatcher("/layout/mainLayout.jsp");
		rd.forward(request, response);
	}
}
