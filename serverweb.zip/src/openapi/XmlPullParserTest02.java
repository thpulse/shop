package openapi;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;
import org.xmlpull.v1.builder.XmlBuilderException;

public class XmlPullParserTest02 {

	public static void main(String[] args) {
		
		try{
			//1. �ļ��� factory�� ���ؼ� ����
			XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
			XmlPullParser parser = factory.newPullParser();
			
			//2. �Ľ��� ������ ���� - ����(URL�� �̿�), ����(BufferedInputStream)
			BufferedInputStream bis = new BufferedInputStream(new FileInputStream("src/openapi/dept.xml"));
			
			//3. parser�� ��Ʈ�� ����
			parser.setInput(bis, "utf-8");
			
			//4. parser�� �̺�Ʈ�� ������ ���� ����
			String tag ="";
			String code = "";
			String name = "";
			String loc = "";
			String tel = "";
			
			ArrayList<DeptDTO> deptlist = new ArrayList<DeptDTO>();
			
			int eventType = parser.getEventType();
			while(eventType != XmlPullParser.END_DOCUMENT) {
				if(eventType == XmlPullParser.START_TAG) {
					System.out.println("�±��̸� : " + parser.getName());
					tag = parser.getName();
				}else if(eventType == XmlPullParser.TEXT) {
					if(tag.equals("code") & !parser.getText().contains("\n")) {
						code = parser.getText();
					}else if(tag.equals("name") & !parser.getText().contains("\n")) {
						name = parser.getText();
					}else if(tag.equals("loc") & !parser.getText().contains("\n")) {
						loc = parser.getText();
					}else if(tag.equals("tel") & !parser.getText().contains("\n")) {
						tel = parser.getText();
					}
				}else if(eventType == XmlPullParser.END_TAG ) {
					tag = parser.getName();
					if(tag.equals("dept")){
						DeptDTO dept = new DeptDTO(code, name, loc, tel);
						deptlist.add(dept);
					}
				}
				//���� �̺�Ʈ�� �ѱ��
				eventType = parser.next();
			}
			System.out.println("************");
			print(deptlist);
		}catch(XmlPullParserException e){
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void print(ArrayList<DeptDTO> deptlist) {
		for(int i = 0; i < deptlist.size(); i++) {
			DeptDTO result = deptlist.get(i);
			System.out.print(result.getCode() + "\t");
			System.out.print(result.getName() + "\t");
			System.out.print(result.getLoc() + "\t");
			System.out.println(result.getTel() + "\t");
			
		}
	}

}
