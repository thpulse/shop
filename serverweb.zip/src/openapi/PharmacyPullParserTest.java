package openapi;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;

import openapi.dto.PharmacyDTO;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

public class PharmacyPullParserTest {
	public static void main(String[] args) {
		
		try{
			String addr_Val = "http://openapi.hira.or.kr/openapi/service/pharmacyInfoService/getParmacyBasisList?ServiceKey=j9anXFgbWl%2BU8hlbtcehps2zBG8%2FFsTSQscVxn0tOy04XDPddpzeYbzAUa1w4AGidHcisrFkGrT6nIHfNtWhKw%3D%3D";
			URL url = new URL(addr_Val);
			
			//1. �ļ��� factory�� ���ؼ� ����
			XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
			XmlPullParser parser = factory.newPullParser();
			
			//2. �Ľ��� ������ ���� - ����(URL�� �̿�), ����(BufferedInputStream)
			InputStream data = url.openStream();
			BufferedInputStream bis = new BufferedInputStream(data);
					
			//3. parser�� ��Ʈ�� ����
			parser.setInput(bis, "utf-8");
			
			//4. parser�� �̺�Ʈ�� ������ ���� ����
			String tag ="";
			String addr ="";
			String emdongNm = "";
			String telno = "";
			
			ArrayList<PharmacyDTO> dtolist = new ArrayList<PharmacyDTO>();
			int eventType = parser.getEventType();
			
			while(eventType != XmlPullParser.END_DOCUMENT) {
				if(eventType == XmlPullParser.START_TAG) {
					//System.out.println("�±��̸� : " + parser.getName());
					tag = parser.getName();
				}else if(eventType == XmlPullParser.TEXT) {
					if(tag.equals("addr") & !parser.getText().contains("\n")) {
						addr = parser.getText();
					}else if(tag.equals("emdongNm") & !parser.getText().contains("\n")) {
						emdongNm = parser.getText();
					}else if(tag.equals("telno") & !parser.getText().contains("\n")) {
						telno = parser.getText();
					}
				}else if(eventType == XmlPullParser.END_TAG ) {
					tag = parser.getName();
					if(tag.equals("item")){
						PharmacyDTO dto = new PharmacyDTO(addr,emdongNm,telno);
						dtolist.add(dto);
					}
				}
				//���� �̺�Ʈ�� �ѱ��
				eventType = parser.next();
			}
			System.out.println("************");
			print(dtolist);
		}catch(XmlPullParserException e){
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void print(ArrayList<PharmacyDTO> deptlist) {
		for(int i = 0; i < deptlist.size(); i++) {
			PharmacyDTO result = deptlist.get(i);
			System.out.print(result.getAddr() + "\t");
			System.out.print(result.getEmdongNm() + "\t");
			System.out.println(result.getTelno() + "\t");
		}
	}

}
