package openapi.service;

import java.util.ArrayList;

import openapi.dto.PharmacyDTO;
import openapi.logic.OpenAPILogicImpl;

public class OpenAPIServiceImpl implements OpenAPIService {

	@Override
	public ArrayList<PharmacyDTO> getPaharmacyList() {
		OpenAPILogicImpl logic = new OpenAPILogicImpl();
		return logic.getPaharmacyList();
	}

}
