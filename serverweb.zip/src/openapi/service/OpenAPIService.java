package openapi.service;

import java.util.ArrayList;

import openapi.dto.PharmacyDTO;

public interface OpenAPIService {
	ArrayList<PharmacyDTO> getPaharmacyList();
}
