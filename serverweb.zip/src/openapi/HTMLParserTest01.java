package openapi;

import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;



public class HTMLParserTest01 {
	public static void main(String[] args) {
		
		try {
			Document doc = Jsoup.connect("http://weather.naver.com/period/pastWetrMain.nhn?ym=201610&naverRgnCd=09680").get();
			if(doc != null){
				//"ol#realrank > li:not(#lastrank) > a"
				Elements elements = doc.select("div#print_content > .tbl_calendar");
				//Elements elements2 = elements.get(0).select("tr").;
				//elements2.select("line");
				//System.out.println("elements2 :" + elements2);
				System.out.println("-----------------");
				
				
				int size = elements.size();
				for(int i =0; i < size; i++) {
					
					System.out.println("================");
					
					/*
					 * Element atag = elements.get(i);
					 * System.out.println((i+1) + atag.attr("title"));
					System.out.println((i+1) +"���� : " + atag.select("span.tx").text());
					System.out.println((i+1) +"�ܰ� : " + atag.select("span.rk").text());*/
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
}
