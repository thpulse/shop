package openapi;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;
import org.xmlpull.v1.builder.XmlBuilderException;

public class XmlPullParserTest01 {

	public static void main(String[] args) {
		
		try{
			//1. �ļ��� factory�� ���ؼ� ����
			XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
			XmlPullParser parser = factory.newPullParser();
			
			//2. �Ľ��� ������ ���� - ����(URL�� �̿�), ����(BufferedInputStream)
			BufferedInputStream bis = new BufferedInputStream(new FileInputStream("src/openapi/dept.xml"));
			
			//3. parser�� ��Ʈ�� ����
			parser.setInput(bis, "utf-8");
			
			//4. parser�� �̺�Ʈ�� ������ ���� ����
			int eventType = parser.getEventType();
			while(eventType != XmlPullParser.END_DOCUMENT) {
				switch(eventType) {
				case XmlPullParser.START_DOCUMENT:
					System.out.println("Start Document");
					break;
				case XmlPullParser.START_TAG: 
					System.out.println("Start Tag");
					break;
				case XmlPullParser.TEXT: 
					System.out.println("TEXT Tag");
					break;
				case XmlPullParser.END_DOCUMENT: 
					System.out.println("END_DOCUMENT Tag");
					break;
				}
				//���� �̺�Ʈ�� �ѱ��
				eventType = parser.next();
			}
			//System.out.println("i");
			
			
		}catch(XmlPullParserException e){
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
