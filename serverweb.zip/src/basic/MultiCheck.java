package basic;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class MultiCheck extends HttpServlet {
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		
		req.setCharacterEncoding("euc-kr");
		res.setContentType("text/html;charset=euc-kr");
		
		PrintWriter pw = res.getWriter();
		
		String name = req.getParameter("name");
		String addr = req.getParameter("addr");
		String[] sw = req.getParameterValues("sw");
		
		System.out.println("name : " + name);
		System.out.println("addr : " + addr);
		
		String sw_Val=""; 
		for(int i=0; i < sw.length; i++) {
			sw_Val = sw_Val + sw[i] + " ";
		}
		System.out.println("Software : " + sw_Val);
		
		pw.print("<h1>name		:" + name +"</h1>");
		pw.print("<h1>addr		:" + addr +"</h1>");
		pw.print("<h1>Software	:" + sw_Val +"</h1>");
		
		
		
		
	}

}
