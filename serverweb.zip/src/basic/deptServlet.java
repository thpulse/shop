package basic;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Vector;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.catalina.connector.Request;

import dept.dto.DeptDTO;
import dept.service.DeptService;
import dept.service.DeptServiceImpl;

@WebServlet(name = "deptinsert", urlPatterns = { "/deptinsert.do" })
public class deptServlet extends HttpServlet{
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {
		req.setCharacterEncoding("euc-kr");
			
		String deptno 	= req.getParameter("deptno");
		String deptname = req.getParameter("deptname");
		String loc 		= req.getParameter("loc");
		String tel 		= req.getParameter("tel");
		String mgr 		= req.getParameter("mgr");
		
		DeptDTO dto = new DeptDTO();
		
		dto.setDeptName(deptname);
		dto.setDeptNo(deptno);
		dto.setLoc(loc);
		dto.setMgr(mgr);
		dto.setTel(tel);
		
		DeptService service = new DeptServiceImpl();
		int result = service.insert(dto);
		String mainurl="";
		if(result > 0) {
			mainurl = "../jspbasic/insertResult.jsp";
		}else {
			mainurl = "../dept/dept_register.jsp";
		}
		req.setAttribute("result", result); 
		req.setAttribute("menu", "../layout/dept_menu.jsp");
		req.setAttribute("mainurl", mainurl);
		RequestDispatcher rd =
				req.getRequestDispatcher("/layout/mainLayout.jsp");
		rd.forward(req,res);
	}
}
