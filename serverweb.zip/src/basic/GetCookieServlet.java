package basic;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet(name = "getCookie", urlPatterns = { "/getCookie" })
public class GetCookieServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//��Ű������ req�������� �����´�.
		//��Ű�� ������ name���� ��
		Cookie[] cookies = request.getCookies();
		String title = "";
		String page = "";
		for(int i =0; i < cookies.length; i++) {
			if(cookies[i].getName().equals("title")){
				title = cookies[i].getValue();
			}else if(cookies[i].getName().equals("page")){
				page = cookies[i].getValue() + "page";
			}
		}
		request.setAttribute("title", title);	
		request.setAttribute("page", page);	
		RequestDispatcher rd = request.getRequestDispatcher("/jspbasic2/cookieResult.jsp");
		rd.forward(request, response);
	}
}
