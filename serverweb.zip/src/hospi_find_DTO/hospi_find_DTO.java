package hospi_find_DTO;
//��������ð��� ���� �� ����
public class hospi_find_DTO {
	private String dutyAddr;		//�ּ�
	private String dutyDiv;			//�����з� ( ���� �����۾�)
	private String dutyEmcls;		//??
	private String dutyEmclsName;	//??
	private String dutyEryn;		//���޽ǿ���� (1 : ����, �� ��)
	private String dutyMapimg;		//���̾൵
	private String dutyName;		//�����
	private String dutyTel1;		//��ǥ��ȭ1
	private String hpid;			//���ID
	private String postCdn1;		//������ȣ 1		
	private String postCdn2;		//������ȣ 2
	private String wgs84Lat;		//��������
	private String wgs84Lon;		//�����浵
	
	
	public hospi_find_DTO(){};
	public hospi_find_DTO(String dutyAddr, String dutyDiv, String dutyEmcls,
			String dutyEmclsName, String dutyEryn, String dutyMapimg,
			String dutyName, String dutyTel1, String hpid, String postCdn1,
			String postCdn2, String rnum, String wgs84Lat, String wgs84Lon) {
		super();
		this.dutyAddr = dutyAddr;
		this.dutyDiv = dutyDiv;
		this.dutyEmcls = dutyEmcls;
		this.dutyEmclsName = dutyEmclsName;
		this.dutyEryn = dutyEryn;
		this.dutyMapimg = dutyMapimg;
		this.dutyName = dutyName;
		this.dutyTel1 = dutyTel1;
		this.hpid = hpid;
		this.postCdn1 = postCdn1;
		this.postCdn2 = postCdn2;
		this.wgs84Lat = wgs84Lat;
		this.wgs84Lon = wgs84Lon;
	}
	
	public hospi_find_DTO(String wgs84Lat, String wgs84Lon, String dutyName, String hpid) {
		super();
		this.wgs84Lat = wgs84Lat;
		this.wgs84Lon = wgs84Lon;
		this.dutyName = dutyName;
		this.hpid = hpid;
	}
	
	public hospi_find_DTO(String wgs84Lat, String wgs84Lon){
		super();
		this.wgs84Lat = wgs84Lat;
		this.wgs84Lon = wgs84Lon;
	}
	public String getDutyAddr() {
		return dutyAddr;
	}
	public void setDutyAddr(String dutyAddr) {
		this.dutyAddr = dutyAddr;
	}
	public String getDutyDiv() {
		return dutyDiv;
	}
	public void setDutyDiv(String dutyDiv) {
		this.dutyDiv = dutyDiv;
	}
	public String getDutyEmcls() {
		return dutyEmcls;
	}
	public void setDutyEmcls(String dutyEmcls) {
		this.dutyEmcls = dutyEmcls;
	}
	public String getDutyEmclsName() {
		return dutyEmclsName;
	}
	public void setDutyEmclsName(String dutyEmclsName) {
		this.dutyEmclsName = dutyEmclsName;
	}
	public String getDutyEryn() {
		return dutyEryn;
	}
	public void setDutyEryn(String dutyEryn) {
		this.dutyEryn = dutyEryn;
	}
	public String getDutyMapimg() {
		return dutyMapimg;
	}
	public void setDutyMapimg(String dutyMapimg) {
		this.dutyMapimg = dutyMapimg;
	}
	public String getDutyName() {
		return dutyName;
	}
	public void setDutyName(String dutyName) {
		this.dutyName = dutyName;
	}
	public String getDutyTel1() {
		return dutyTel1;
	}
	public void setDutyTel1(String dutyTel1) {
		this.dutyTel1 = dutyTel1;
	}
	public String getHpid() {
		return hpid;
	}
	public void setHpid(String hpid) {
		this.hpid = hpid;
	}
	public String getPostCdn1() {
		return postCdn1;
	}
	public void setPostCdn1(String postCdn1) {
		this.postCdn1 = postCdn1;
	}
	public String getPostCdn2() {
		return postCdn2;
	}
	public void setPostCdn2(String postCdn2) {
		this.postCdn2 = postCdn2;
	}
	
	public String getWgs84Lat() {
		return wgs84Lat;
	}
	public void setWgs84Lat(String wgs84Lat) {
		this.wgs84Lat = wgs84Lat;
	}
	public String getWgs84Lon() {
		return wgs84Lon;
	}
	public void setWgs84Lon(String wgs84Lon) {
		this.wgs84Lon = wgs84Lon;
	}
	
	@Override
	public String toString() {
		return "hospi_find_DTO [dutyAddr=" + dutyAddr + ", dutyDiv=" + dutyDiv
				+ ", dutyEmcls=" + dutyEmcls + ", dutyEmclsName="
				+ dutyEmclsName + ", dutyEryn=" + dutyEryn + ", dutyMapimg="
				+ dutyMapimg + ", dutyName=" + dutyName + ", dutyTel1="
				+ dutyTel1 + ", hpid=" + hpid + ", postCdn1=" + postCdn1
				+ ", postCdn2=" + postCdn2 + ", wgs84Lat="
				+ wgs84Lat + ", wgs84Lon=" + wgs84Lon + "]";
	}
}
