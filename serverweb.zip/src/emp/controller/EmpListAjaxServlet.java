package emp.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import emp.dto.EmpDTO;
import emp.service.EmpService;
import emp.service.EmpServiceImpl;

/**
 * Servlet implementation class EmpListAjaxServlet
 */
@WebServlet(name = "empajaxlist", urlPatterns = { "/empajaxlist.do" })
public class EmpListAjaxServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		
		String deptNo = request.getParameter("deptNo");
		EmpService service = new EmpServiceImpl();
		ArrayList<EmpDTO> dto = null;
		dto = service.member_list(deptNo);
		System.out.println("EmpListAjaxServlet : " + deptNo );
		
		JSONObject jsonResult = new JSONObject();
		JSONArray jsonlist = new JSONArray();
		for(int i =0; i < dto.size(); i++) {
			EmpDTO obj = dto.get(i);
			JSONObject json = new JSONObject();
			json.put("DeptNo", obj.getDeptNo());
			json.put("Grade", obj.getGrade());
			json.put("Hiredate",obj.getHiredate());
			json.put("Id",obj.getId());
			json.put("Name",obj.getName());
			json.put("Pass",obj.getPass());
			json.put("Point", obj.getPoint());
			jsonlist.add(json);			
		}
		jsonResult.put("result_emplist", jsonlist);
		System.out.println(jsonResult.toString());
		response.setContentType("application/json;charset=utf-8");
		response.setHeader("cache-control", "no-cache, no-store");
		PrintWriter pw = response.getWriter();
		pw.print(jsonResult.toJSONString());
	}
}
