package emp.controller;

import java.io.IOException;
import java.net.URLEncoder;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import emp.dto.EmpDTO;
import emp.service.EmpService;
import emp.service.EmpServiceImpl;

@WebServlet(name = "login", urlPatterns = { "/login.do" })
public class LoginServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("euc-kr");

		String id	= request.getParameter("id");
		String pass = request.getParameter("pass");
		String id_chk_Val = request.getParameter("member_id_save");
		
		System.out.println("lofingServlet id_chk_Val : " + id_chk_Val);
		EmpService service = new EmpServiceImpl();
		EmpDTO loginUser = new EmpDTO();
		loginUser = service.login(id, pass);
		
		String mainurl="";
		if(loginUser == null) {
			mainurl = "../emp/login.jsp";
		}else {
			if(id_chk_Val != null) {
				Cookie id_cookie = new Cookie("id_cookie", URLEncoder.encode(id,"euc-kr"));
				id_cookie.setMaxAge(60*60*24);
				response.addCookie(id_cookie);
			}
			mainurl = "../content.jsp";
		}
		//�α����� ������� ������ request�� �ƴ϶� session�� ����Ǿ�� �ϴ� ������
		HttpSession sess = request.getSession();
		sess.setAttribute("loginUser", loginUser); 
		
		request.setAttribute("menu", "../layout/emp_menu.jsp");
		request.setAttribute("mainurl", mainurl);
		RequestDispatcher rd =
				request.getRequestDispatcher("/layout/mainLayout.jsp");
		rd.forward(request,response);
		
	}

}
