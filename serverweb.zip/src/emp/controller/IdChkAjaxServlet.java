package emp.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import emp.dto.EmpDTO;
import emp.service.EmpService;
import emp.service.EmpServiceImpl;
@WebServlet(name = "idchkajax", urlPatterns = { "/idchk_ajax.do" })
public class IdChkAjaxServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		PrintWriter pw = response.getWriter();
		
		String id = request.getParameter("id");
		EmpService service = new EmpServiceImpl();
		boolean result = service.idCheck(id);
		
		String msg = "";
		if(result) {
			msg = "��� �Ұ����� ���̵� : " + id;
		}else {
			msg = "��밡���� ���̵� : " + id;
		}
		pw.print(msg);
	}
}
