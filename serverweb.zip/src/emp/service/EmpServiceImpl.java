package emp.service;

import static fw.DBUtil.*;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

import emp.dao.EmpDAO;
import emp.dao.EmpDAOImple;
import emp.dto.EmpDTO;

public class EmpServiceImpl implements EmpService{
	@Override
	public EmpDTO login(String id, String pass) {
		EmpDTO result = null;
		System.out.println("EmpServiceImpl : " + id + " / " + pass);
		EmpDAO dao =  new EmpDAOImple();
		Connection con = null;
		try{
			con = getConnection();
			result = dao.login(id, pass, con);
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			close(con);
		}
		return result;
	}

	@Override
	public boolean idCheck(String id) {
		boolean result = false;
		System.out.println("EmpServiceImpl : " + id);
		EmpDAO dao =  new EmpDAOImple();
		Connection con  = null;
		try {
			con = getConnection();
			result = dao.idCheck(id,con);
		}catch(SQLException e){
			e.printStackTrace();
		}finally {
			close(con);
		}
		return result;
	}

	@Override
	public ArrayList<EmpDTO> member_list(String deptNo) {
		ArrayList<EmpDTO> result = null;
		System.out.println("EmpServiceImple deptNo : " + deptNo);
		EmpDAO dao = new EmpDAOImple();
		Connection con = null;
		try{
			con = getConnection();
			result = dao.member_list(deptNo, con);
		}catch(SQLException e){
			e.printStackTrace();
		}finally{
			close(con);
		}
		return result;
	}

}
