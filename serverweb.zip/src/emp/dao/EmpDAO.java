package emp.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Vector;

import dept.dto.DeptDTO;
import emp.dto.EmpDTO;

public interface EmpDAO {
	
	EmpDTO login(String id, String pass, Connection con)throws SQLException;
	boolean idCheck(String id, Connection con) throws SQLException;
	ArrayList<EmpDTO> member_list(String deptNo, Connection con) throws SQLException;
}
