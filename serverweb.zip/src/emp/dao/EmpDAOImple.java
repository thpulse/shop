package emp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import emp.dto.EmpDTO;
import static fw.EmpQuery.*;
public class EmpDAOImple implements EmpDAO {
	@Override
	public EmpDTO login(String id, String pass, Connection con)
			throws SQLException {
		EmpDTO result = null;
		System.out.println("EmpDAOImple :" +id +" / " + pass);
		ResultSet rs = null;
		
		PreparedStatement ptmt = con.prepareStatement(loginChk);
		
		ptmt.setString(1, id);
		ptmt.setString(2, pass);
		rs = ptmt.executeQuery();
		if(rs.next()){
			result = new EmpDTO();
			result.setId(rs.getString(1));
			result.setName(rs.getString(2));
			result.setPass(rs.getString(3));
			result.setHiredate(rs.getString(4));
			result.setGrade(rs.getString(5));
			result.setPoint(rs.getInt(6));
			result.setDeptNo(rs.getString(7));
			
		}
		System.out.println("EmpDAOImpl result : " + result);
		return result;
	}

	@Override
	public boolean idCheck(String id, Connection con) throws SQLException {
		boolean result = false;
		System.out.println("EmpDAOImple idcheck :" +id );
		ResultSet rs = null;
		
		PreparedStatement ptmt = con.prepareStatement(idCheck);
		ptmt.setString(1, id);
		rs = ptmt.executeQuery();
		
		if(rs.next()){
			result = true;
		}
		System.out.println("EmpDAOImpl idCheck : " + result);
		return result;
	}

	@Override
	public ArrayList<EmpDTO> member_list(String deptNo, Connection con)
			throws SQLException {
		System.out.println("EmpDAOImple deptno : " + deptNo);
		ArrayList<EmpDTO> emplist = new ArrayList<EmpDTO>();
		ResultSet rs = null;
		PreparedStatement ptmt = con.prepareStatement(MEMBER_LIST);
		ptmt.setString(1,  deptNo);
		rs = ptmt.executeQuery();
		while(rs.next()) {
			EmpDTO dto = new EmpDTO();
			dto.setId(rs.getString(1));
			dto.setName(rs.getString(2));
			dto.setPass(rs.getString(3));
			dto.setHiredate(rs.getString(4));
			dto.setGrade(rs.getString(5));
			dto.setPoint(rs.getInt(6));
			dto.setDeptNo(rs.getString(7));
			emplist.add(dto);
		}
		System.out.println("EmpDAOImple result : " + emplist);
		return emplist;
	}

}
