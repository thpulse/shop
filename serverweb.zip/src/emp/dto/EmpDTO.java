package emp.dto;

public class EmpDTO {
	private String id;
	private String name;
	private String pass;
	private String hiredate;
	private String grade;
	private int point;
	private String deptNo;
	
	public EmpDTO(){}
	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getPass() {
		return pass;
	}


	public void setPass(String pass) {
		this.pass = pass;
	}


	public String getHiredate() {
		return hiredate;
	}


	public void setHiredate(String hiredate) {
		this.hiredate = hiredate;
	}


	public String getGrade() {
		return grade;
	}


	public void setGrade(String grade) {
		this.grade = grade;
	}


	public int getPoint() {
		return point;
	}


	public void setPoint(int point) {
		this.point = point;
	}


	public String getDeptNo() {
		return deptNo;
	}


	public void setDeptNo(String deptNo) {
		this.deptNo = deptNo;
	}


	public EmpDTO(String id, String name, String pass, String hiredate,
			String grade, int point, String deptNo) {
		super();
		this.id = id;
		this.name = name;
		this.pass = pass;
		this.hiredate = hiredate;
		this.grade = grade;
		this.point = point;
		this.deptNo = deptNo;
	}

	
	
}
